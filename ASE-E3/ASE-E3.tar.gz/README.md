完成对menu的打桩测试;

在文件夹目录下，直接运行make指令即可完成编译并执行test;

输入make clean完成对.o和test文件的清理;

谢谢阅读。

